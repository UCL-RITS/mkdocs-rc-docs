#!/bin/bash -l
# This wrapper script is intended to support independent execution.
# 
# Modified for Legion/Grace April 2018 - BAA/WH
# Updated for R2018b on Myriad/Legion/Grace January 2019
#
#$ -l mem=2G
#$ -l matlab=1
#$ -jsv /shared/ucl/apps/Matlab/toolbox_local/Legion/envset.jsv
#$ -cwd
#
# Ensure that under Grid Engine, we're in /bin/bash too:
#$ -S /bin/bash
# 
# This script uses the following environment variables set by the submit MATLAB code:
# MDCE_MATLAB_EXE     - the MATLAB executable to use
# MDCE_MATLAB_ARGS    - the MATLAB args to use
#

# Copyright 2010-2017 The MathWorks, Inc.

cd $MDCE_STORAGE_LOCATION

echo "Matlab variables are set to:"
echo ""
echo "MDCE_DECODE_FUNCTION: $MDCE_DECODE_FUNCTION"
echo "MDCE_MATLAB_EXE: $MDCE_MATLAB_EXE"
echo "MDCE_MATLAB_ARG: $MDCE_MATLAB_ARGS"
echo "MDCE_TASK_LOCATION: $MDCE_TASK_LOCATION"
echo ""
echo "Working directory:"
echo ""
pwd
echo ""

# Load the Matlab module on legion/Grace/Myriad

module load gcc-libs/4.9.2
module load xorg-utils/X11R7.7
module load matlab/full/r2018b/9.5
module list
echo ""


echo "Executing: ${MDCE_MATLAB_EXE} ${MDCE_MATLAB_ARGS}"
eval "${MDCE_MATLAB_EXE}" ${MDCE_MATLAB_ARGS}
EXIT_CODE=${?}
echo "Exiting with code: ${EXIT_CODE}"
exit ${EXIT_CODE}

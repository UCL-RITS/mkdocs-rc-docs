#!/bin/sh

# Copyright 2006-2016 The MathWorks, Inc.

# Stop MATLAB pe - simply clean up $TMPDIR/machines

/bin/rm -f "$TMPDIR/machines"
#!/bin/bash -l
# This wrapper script is intended to support independent execution.
#
# Modified for Myriad/Grace April 2018 - BAA/WH
# Updated for R2019b December 2019
# Updated for R2021a on Kathleen/Myriad April 2021.
#
#$ -l mem=2G
#$ -l matlab=1
#$ -jsv /shared/ucl/apps/Matlab/toolbox_local/envset.jsv
#$ -cwd
#
# Ensure that under Grid Engine, we're in /bin/bash too:
#$ -S /bin/bash
#
# This script uses the following environment variables set by the submit MATLAB code:
# PARALLEL_SERVER_MATLAB_EXE  - the MATLAB executable to use
# PARALLEL_SERVER_MATLAB_ARGS - the MATLAB args to use

# Copyright 2010-2020 The MathWorks, Inc.

# If PARALLEL_SERVER_ environment variables are not set, assign any
# available values with form MDCE_ for backwards compatibility
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE:="${MDCE_MATLAB_EXE}"}
PARALLEL_SERVER_MATLAB_ARGS=${PARALLEL_SERVER_MATLAB_ARGS:="${MDCE_MATLAB_ARGS}"}

# Load the Matlab module on Kathleen/Myriad - need the Intel MPI module as well.

module load gcc-libs/4.9.2
module load xorg-utils/X11R7.7
module load matlab/full/r2021a/9.10
module list
echo ""

if [ ! -z "${SGE_TASK_ID}" ] && [ "${SGE_TASK_ID}" != "undefined" ]; then
    # Use job arrays
    export PARALLEL_SERVER_TASK_LOCATION="${PARALLEL_SERVER_JOB_LOCATION}/Task${SGE_TASK_ID}";
fi

echo "Executing: ${PARALLEL_SERVER_MATLAB_EXE} ${PARALLEL_SERVER_MATLAB_ARGS}"
eval "${PARALLEL_SERVER_MATLAB_EXE}" ${PARALLEL_SERVER_MATLAB_ARGS}
EXIT_CODE=${?}
echo "Exiting with code: ${EXIT_CODE}"
exit ${EXIT_CODE}
